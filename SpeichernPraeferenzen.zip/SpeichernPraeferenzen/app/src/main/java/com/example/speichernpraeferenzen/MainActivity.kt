package com.example.speichernpraeferenzen

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Context
import com.example.speichernpraeferenzen.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        val speicher = this.getSharedPreferences(
                "daten.pr", Context.MODE_PRIVATE)

        B.buSchreiben.setOnClickListener {
            val schreiber = speicher.edit()
            schreiber.putInt("z", 42)
            schreiber.putFloat("x", 47.11f)
            schreiber.putString("t", "Hallo Welt")
            if(!schreiber.commit())
                B.tvAusgabe.text = "Problem beim Schreiben"
        }

        B.buLesen.setOnClickListener {
            try {
                val z = if (speicher.contains("z"))
                    speicher.getInt("z", 0) else -1
                val x = if (speicher.contains("x"))
                    speicher.getFloat("x", 0.0f) else -1.0f
                val t = if (speicher.contains("t"))
                    speicher.getString("t", "") else "(Kein String)"
                B.tvAusgabe.text = "$z $x $t"
            }
            catch(ex:Exception) {
                B.tvAusgabe.text = ex.toString()
            }
        }

        B.buLoeschenEinzeln.setOnClickListener {
            val schreiber = speicher.edit()
            schreiber.remove("x")
            if(!schreiber.commit())
                B.tvAusgabe.text = "Problem beim Löschen"
        }

        B.buLoeschenAlle.setOnClickListener {
            val schreiber = speicher.edit()
            schreiber.clear()
            if(!schreiber.commit())
                B.tvAusgabe.text = "Problem beim Löschen"
        }
    }
}
