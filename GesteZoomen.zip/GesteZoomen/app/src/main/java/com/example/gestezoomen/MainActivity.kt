package com.example.gestezoomen

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.gestezoomen.databinding.ActivityMainBinding
import kotlin.math.*

import android.view.MotionEvent
import android.view.ScaleGestureDetector

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding
    private lateinit var sgd: ScaleGestureDetector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        sgd = ScaleGestureDetector(this,
                object:ScaleGestureDetector.OnScaleGestureListener {
                    private var faktor = 1.0f

                    override fun onScale(detector: ScaleGestureDetector): Boolean {
                        faktor *= detector.scaleFactor
                        B.ivBild.scaleX = faktor
                        B.ivBild.scaleY = faktor
                        B.tvAusgabeFaktor.text = "Faktor: ${round(faktor * 100) / 100}"
                        return true
                    }

                    override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                        B.tvAusgabeVerlauf.text = "Beginn"
                        return true
                    }

                    override fun onScaleEnd(detector: ScaleGestureDetector) {
                        B.tvAusgabeVerlauf.text = "Ende"
                    }
                })
    }

    override fun onTouchEvent(motionEvent: MotionEvent): Boolean {
        sgd.onTouchEvent(motionEvent)
        return true
    }
}
