package com.example.systemaudio

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import com.example.systemaudio.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        B.buEinfach.setOnClickListener {
            val mpEinfach = MediaPlayer.create(this, R.raw.gitarre)
            mpEinfach.start()
        }

        var mp = MediaPlayer()
        var status = 0
        val steuerung = Handler(Looper.getMainLooper())
        var resId = R.raw.gitarre

        B.pbAusgabe.max = 100

        val ereignis = object:Runnable {
            override fun run() {
                B.tvGesamt.text = "${mp.duration} msec."
                B.tvAktuell.text = "${mp.currentPosition} msec."
                B.pbAusgabe.progress =
                        100 * mp.currentPosition / mp.duration

                if(mp.isPlaying)
                    steuerung.postDelayed(this, 500L)
                else {
                    B.buStart.text = "Start"
                    status = 0
                    B.pbAusgabe.progress = 0
                }
            }
        }

        B.rgDatei.setOnCheckedChangeListener { _, checkedId ->
            resId = if(checkedId == B.rbGitarre.id)
                R.raw.gitarre else R.raw.ende
        }

        B.buStart.setOnClickListener {
            if(status == 0) {
                mp.release()
                mp = MediaPlayer.create(this, resId)
                mp.start()
                steuerung.postDelayed(ereignis, 0L)
                B.buStart.text = "Pause"
                status = 1
            }

            else if(status == 1) {
                mp.pause()
                steuerung.removeCallbacks(ereignis)
                B.buStart.text = "Weiter"
                status = 2
            }

            else if(status == 2) {
                mp.start()
                steuerung.postDelayed(ereignis, 0L)
                B.buStart.text = "Pause"
                status = 1
            }
        }

        B.buStop.setOnClickListener {
            mp.stop()
            steuerung.removeCallbacks(ereignis)
            B.buStart.text = "Start"
            status = 0
            B.tvAktuell.text = "0 msec."
            B.pbAusgabe.progress = 0
        }
    }
}
