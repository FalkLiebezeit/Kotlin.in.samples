package com.example.zeitsteuerung

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.zeitsteuerung.databinding.ActivityMainBinding
import android.os.Handler
import android.os.Looper

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding
    private var zaehler = 0
    private var ausgabe = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        val steuerung = Handler(Looper.getMainLooper())
        startZustand()

        val ereignis = object:Runnable {
            override fun run() {
                zaehler++
                B.pbAusgabe.progress = zaehler
                ausgabe += "$zaehler "
                B.tvAusgabe.text = ausgabe

                if(zaehler <= 9)
                    steuerung.postDelayed(this, 500L)
                else
                    startZustand()
            }
        }

        B.buStart.setOnClickListener {
            B.buStart.isEnabled = false
            B.buPause.isEnabled = true
            B.buStop.isEnabled = true
            steuerung.postDelayed(ereignis, 0L)
        }

        B.buPause.setOnClickListener{
            B.buStart.isEnabled = true
            B.buStart.text = "Weiter"
            B.buPause.isEnabled = false
            steuerung.removeCallbacks(ereignis)
        }

        B.buStop.setOnClickListener{
            B.buStart.isEnabled = true
            B.buPause.isEnabled = false
            B.buStop.isEnabled = false
            steuerung.removeCallbacks(ereignis)
            startZustand()
        }
    }

    private fun startZustand() {
        zaehler = 0
        ausgabe = ""
        B.tvAusgabe.text = ausgabe
        B.buStart.isEnabled = true
        B.buPause.isEnabled = false
        B.buStop.isEnabled = false
        B.buStart.text = "Start"
        B.pbAusgabe.progress = zaehler
    }
}
