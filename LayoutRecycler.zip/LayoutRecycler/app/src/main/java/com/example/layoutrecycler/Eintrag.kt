package com.example.layoutrecycler

import androidx.recyclerview.widget.RecyclerView
import com.example.layoutrecycler.databinding.ActivityEintragBinding

class Eintrag(val bindungEintrag: ActivityEintragBinding) :
    RecyclerView.ViewHolder(bindungEintrag.root)
