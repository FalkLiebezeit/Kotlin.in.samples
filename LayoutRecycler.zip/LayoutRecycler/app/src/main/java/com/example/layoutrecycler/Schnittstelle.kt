package com.example.layoutrecycler

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.layoutrecycler.databinding.ActivityEintragBinding
import com.google.android.material.snackbar.Snackbar

class Schnittstelle(private val liste: ArrayList<String>) :
        RecyclerView.Adapter<Eintrag>() {
    override fun getItemCount(): Int {
        return liste.size
    }

    override fun onCreateViewHolder(parent: ViewGroup,
                                    viewType: Int): Eintrag {
        val entfalter = LayoutInflater.from(parent.context)
        val bindungEintrag = ActivityEintragBinding.inflate(
            entfalter, parent, false)
        return Eintrag(bindungEintrag)
    }

    override fun onBindViewHolder(eintragObjekt: Eintrag, index: Int)
    {
        eintragObjekt.bindungEintrag.eintragLinks.text = "..."
        eintragObjekt.bindungEintrag.eintragRechts.text = liste[index]
        eintragObjekt.bindungEintrag.eintragRechts.setOnClickListener {
            Snackbar.make(it, "Eintrag $index",
                Snackbar.LENGTH_SHORT).show()
        }
    }
}
