package com.example.layoutrecycler

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.layoutrecycler.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var bindungMain: ActivityMainBinding
    private var liste = arrayListOf("Eintrag 0")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bindungMain = ActivityMainBinding.inflate(layoutInflater)
        setContentView(bindungMain.root)

        bindungMain.kreislaufView.layoutManager =
            LinearLayoutManager(this)
        for (i in 1 .. 49)
            liste.add("Eintrag $i")
        bindungMain.kreislaufView.adapter = Schnittstelle(liste)
    }
}
