package com.example.zahleneinstellen

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.zahleneinstellen.databinding.ActivityMainBinding
import android.widget.SeekBar

class MainActivity : AppCompatActivity(),
        SeekBar.OnSeekBarChangeListener {
    private lateinit var B: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        B.sbEins.setOnSeekBarChangeListener(this)
        B.sbZwei.setOnSeekBarChangeListener(this)

        B.buSumme.setOnClickListener {
            val wertEins = B.sbEins.progress
            val wertZwei = (B.sbZwei.progress / 10.0) + 0.5
            val summe = wertEins + wertZwei
            B.tvAusgabe.text = "Summe: $wertEins + $wertZwei = $summe"
        }

        B.buStartwerte.setOnClickListener {
            B.sbEins.progress = 5
            B.sbZwei.progress = 5
        }
    }

    override fun onProgressChanged(
            seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
        val ausloeser = if(fromUser) "Benutzer" else "Button"
        when (seekBar?.id) {
            B.sbEins.id -> {
                B.tvWertEins.text = "$progress"
                B.tvAusgabe.text = "SeekBar: 1, Auslöser: $ausloeser"
            }
            B.sbZwei.id -> {
                val wert = (progress / 10.0) + 0.5
                B.tvWertZwei.text = "$wert"
                B.tvAusgabe.text = "SeekBar: 2, Auslöser: $ausloeser"
            }
        }
    }

    override fun onStartTrackingTouch(seekBar: SeekBar?) {
        val nr = if(seekBar?.id == B.sbEins.id) 1 else 2
        B.tvAusgabe.text = "SeekBar: $nr, Start"
    }

    override fun onStopTrackingTouch(seekBar: SeekBar?) {
        val nr = if(seekBar?.id == B.sbEins.id) 1 else 2
        B.tvAusgabe.text = "SeekBar: $nr, Stop"
    }
}
