package com.example.gesteziehen

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MotionEvent
import android.view.ViewGroup
import com.example.gesteziehen.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        var xDownPx = 0.0f
        var yDownPx = 0.0f

        B.ivBild.setOnTouchListener { view, event ->
            if(event.action == MotionEvent.ACTION_DOWN) {
                xDownPx = event.x
                yDownPx = event.y
            }
            else if(event.action == MotionEvent.ACTION_MOVE) {
                val xDeltaPx = event.x - xDownPx
                val yDeltaPx = event.y - yDownPx

                val positionPx = view.layoutParams
                        as ViewGroup.MarginLayoutParams
                positionPx.leftMargin += xDeltaPx.toInt()
                positionPx.topMargin += yDeltaPx.toInt()
                view.layoutParams = positionPx

                B.tvAusgabe.text =
                    "${event.rawX.toInt()} ${event.rawY.toInt()}"
            }
            view.performClick()
            true
        }
    }
}
