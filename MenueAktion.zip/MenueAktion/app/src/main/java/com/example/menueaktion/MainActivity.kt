package com.example.menueaktion

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import com.example.menueaktion.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.haupt, menu)
        return true
    }

    override fun onOptionsItemSelected(
            item: MenuItem): Boolean {
        when(item.itemId) {
            R.id.itEins   -> B.tvAusgabe.text = "Eins"
            R.id.itZweiA  -> B.tvAusgabe.text = "Zwei A"
            R.id.itZweiB1 -> B.tvAusgabe.text = "Zwei B1"
            R.id.itZweiB2 -> B.tvAusgabe.text = "Zwei B2"
            R.id.itDrei   -> B.tvAusgabe.text = "Drei"
            R.id.itVier   -> B.tvAusgabe.text = "Vier"
            R.id.itFuenf  -> B.tvAusgabe.text = "Fünf"
        }
        return true
    }
}
