package com.example.zoo

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.*
import android.graphics.Color
import android.view.*
import kotlin.math.*
import kotlin.random.Random
import java.util.Calendar
import com.example.zoo.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(), Runnable, View.OnTouchListener {
    private lateinit var B: ActivityMainBinding

    private var richtung = -1
    private val farbe = intArrayOf(Color.RED, Color.YELLOW, Color.GREEN, Color.BLUE)
    private var punkte = 0
    private var zeitStart = 0L
    private var spielBreite = 0
    private var spielHoehe = 0
    private var spielAktiv = true

    private var tierNeuHandler = Handler(Looper.getMainLooper())
    private var tierSteht = 2000.0
    private var tierStehtMin = 1000.0
    private var tierPause = 300L

    private var xDown = 0.0f
    private var yDown = 0.0f
    private val minDiff = 20.0f

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        B.flTier.setOnTouchListener(this)
        spielBreite = resources.displayMetrics.widthPixels
        spielHoehe = resources.displayMetrics.heightPixels

        zeitStart = Calendar.getInstance().time.time
        B.pbZeit.max = 30

        tierNeu()
        tierNeuHandler.postDelayed(this, 0L)
    }

    override fun run() {
        val zeitJetzt = Calendar.getInstance().time.time
        val zeitRest = 30000L - (zeitJetzt - zeitStart)
        B.pbZeit.progress = (zeitRest / 1000L).toInt()

        if(zeitRest < 0L) {
            B.tvPunkte.text = "Ende, Punkte: $punkte"
            tierNeuHandler.removeCallbacks(this)
            spielAktiv = false
        }
        else {
            tierNeu()
            if (tierSteht > tierStehtMin)
                tierSteht *= 0.95
            tierNeuHandler.postDelayed(this, tierSteht.toLong())
        }
    }

    override fun onTouch(v: View?, event: MotionEvent?): Boolean {
        if(!spielAktiv) {
            v?.performClick()
            return true
        }

        when (event?.action) {
            MotionEvent.ACTION_DOWN -> {
                xDown = event.x
                yDown = event.y
            }
            MotionEvent.ACTION_UP -> {
                val xDiff = (event.x - xDown).absoluteValue
                val yDiff = (event.y - yDown).absoluteValue
                var erfolg = false

                // 0=rot=links, 1=gelb=oben, 2=grün=rechts, 3=blau=unten
                when(richtung) {
                    0 -> if (xDiff > minDiff && xDiff > yDiff && event.x < xDown) erfolg = true
                    1 -> if (yDiff > minDiff && yDiff > xDiff && event.y < yDown) erfolg = true
                    2 -> if (xDiff > minDiff && xDiff > yDiff && event.x > xDown) erfolg = true
                    3 -> if (yDiff > minDiff && yDiff > xDiff && event.y > yDown) erfolg = true
                }

                punkte = if(erfolg) punkte + 1 else punkte - 1
                B.tvPunkte.text = "Punkte: $punkte"

                tierNeuHandler.removeCallbacks(this)
                tierNeuHandler.postDelayed(this, tierPause)
            }
        }

        v?.performClick()
        return true
    }

    private fun tierNeu() {
        richtung = (0 .. 3).random()
        B.flTier.setBackgroundColor(farbe[richtung])

        val lp = B.flTier.layoutParams as ViewGroup.MarginLayoutParams
        lp.leftMargin = (Random.nextDouble(0.05, 0.75) * spielBreite).toInt()
        lp.topMargin = (Random.nextDouble(0.05, 0.75) * spielHoehe).toInt()
        B.flTier.layoutParams = lp
    }
}
