package com.example.gestetippen

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MotionEvent
import java.util.Calendar
import com.example.gestetippen.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        var zeitDownMs = 0L
        val zeitGrenzeLangMs = 500L

        var zeitUpVorherMs = 0L
        val zeitGrenzeDoppeltMs = 100L

        B.ivBildEins.setOnTouchListener { view, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                zeitDownMs = Calendar.getInstance().time.time
            }
            else if(event.action == MotionEvent.ACTION_UP) {
                val zeitUpMs = Calendar.getInstance().time.time
                val zeitDeltaMs = zeitUpMs - zeitDownMs
                if (zeitDeltaMs > zeitGrenzeLangMs)
                    B.tvAusgabe.text = "Tipp lang ($zeitDeltaMs ms)"
                else
                    B.tvAusgabe.text = "Tipp normal"
            }
            view.performClick()
            true
        }

        B.ivBildZwei.setOnTouchListener { view, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                zeitDownMs = Calendar.getInstance().time.time
                val zeitDeltaMs = zeitDownMs - zeitUpVorherMs
                if(zeitDeltaMs < zeitGrenzeDoppeltMs)
                    B.tvAusgabe.text = "Tipp doppelt ($zeitDeltaMs ms)"
                else
                    B.tvAusgabe.text = "Tipp einfach"
            }
            else if(event.action == MotionEvent.ACTION_UP) {
                zeitUpVorherMs = Calendar.getInstance().time.time
            }
            view.performClick()
            true
        }
    }
}
