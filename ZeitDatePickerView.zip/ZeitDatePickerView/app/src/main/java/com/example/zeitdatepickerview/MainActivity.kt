package com.example.zeitdatepickerview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Build
import com.example.zeitdatepickerview.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        if (Build.VERSION.SDK_INT >= 26) {
            val sdf = SimpleDateFormat(
                    "dd.MM.yyyy", Locale.getDefault())

            val kal = Calendar.getInstance()
            kal.set(2021, 6, 15)
            B.dpDatum.updateDate(2021, 6, 15)
            val ausgabe = "Datum: " + sdf.format(kal.time)
            B.tvDatum.text = ausgabe

            kal.set(2021, 5, 20)
            B.dpDatum.minDate = kal.timeInMillis
            kal.set(2021, 7, 10)
            B.dpDatum.maxDate = kal.timeInMillis

            B.dpDatum.setOnDateChangedListener {
                _, year, monthOfYear, dayOfMonth ->
                val kalAuswahl = Calendar.getInstance()
                kalAuswahl.set(year, monthOfYear, dayOfMonth)
                val aus = "Datum: " + sdf.format(kalAuswahl.time)
                B.tvDatum.text = aus
            }
        }
        else
            B.tvDatum.text =
                "API-Level min. 26, hier: ${Build.VERSION.SDK_INT}"
    }
}
