package com.example.systemkontakt

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import android.content.pm.PackageManager.PERMISSION_GRANTED
import android.Manifest
import androidx.core.app.ActivityCompat
import android.content.Intent
import android.provider.ContactsContract.Contacts

import java.util.ArrayList
import android.content.ContentProviderOperation
import android.provider.ContactsContract.AUTHORITY
import android.provider.ContactsContract.Data
import android.provider.ContactsContract.RawContacts
import android.provider.ContactsContract.CommonDataKinds.Email
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.ContactsContract.CommonDataKinds.StructuredName

import com.example.systemkontakt.databinding.ActivityMainBinding

const val KONSTANTE_KONTAKT = 123

class MainActivity : AppCompatActivity(),
        ActivityCompat.OnRequestPermissionsResultCallback {
    private lateinit var B: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        if(ActivityCompat.checkSelfPermission(this,
                        Manifest.permission.WRITE_CONTACTS) !=
                PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this,
                    arrayOf(Manifest.permission.WRITE_CONTACTS),
                    KONSTANTE_KONTAKT)

        B.buAnzeigen.setOnClickListener {
            kontaktlisteAnzeigen() }

        B.buHinzufuegen.setOnClickListener {
            val cpoListe =
                    ArrayList<ContentProviderOperation>()

            // Eintrag in Kontaktliste
            val kontaktId = 0
            var cpob = ContentProviderOperation.
            newInsert(RawContacts.CONTENT_URI)
            cpob.withValue(RawContacts.ACCOUNT_TYPE, null)
            cpob.withValue(RawContacts.ACCOUNT_NAME, null)
            var cpo = cpob.build()
            cpoListe.add(cpo)

            // Name
            cpob = ContentProviderOperation.
            newInsert(Data.CONTENT_URI)
            cpob.withValueBackReference(
                    Data.RAW_CONTACT_ID, kontaktId)
            cpob.withValue(Data.MIMETYPE,
                    StructuredName.CONTENT_ITEM_TYPE)
            cpob.withValue(StructuredName.DISPLAY_NAME,
                    B.etAnzeigeName.text.toString())
            cpo = cpob.build()
            cpoListe.add(cpo)

            // Mobilnummer
            cpob = ContentProviderOperation.
            newInsert(Data.CONTENT_URI)
            cpob.withValueBackReference(
                    Data.RAW_CONTACT_ID, kontaktId)
            cpob.withValue(Data.MIMETYPE,
                    Phone.CONTENT_ITEM_TYPE)
            cpob.withValue(Phone.NUMBER,
                    B.etTelefonMobil.text.toString())
            cpob.withValue(Phone.TYPE, Phone.TYPE_MOBILE)
            cpo = cpob.build()
            cpoListe.add(cpo)

            // E-Mail-Adresse
            cpob = ContentProviderOperation.
            newInsert(Data.CONTENT_URI)
            cpob.withValueBackReference(
                    Data.RAW_CONTACT_ID, kontaktId)
            cpob.withValue(Data.MIMETYPE,
                    Email.CONTENT_ITEM_TYPE)
            cpob.withValue(Email.ADDRESS,
                    B.etEMailHome.text.toString())
            cpob.withValue(Email.TYPE, Email.TYPE_HOME)
            cpo = cpob.build()
            cpoListe.add(cpo)

            contentResolver.applyBatch(AUTHORITY, cpoListe)
            kontaktlisteAnzeigen()
        }
    }

    override fun onRequestPermissionsResult(
            requestCode: Int,
            permissions: Array<out String>,
            grantResults: IntArray) {
        if(requestCode == KONSTANTE_KONTAKT &&
                grantResults.isNotEmpty() &&
                grantResults[0] != PERMISSION_GRANTED)
            finish()
    }

    private fun kontaktlisteAnzeigen() {
        val kontakteActivity =
                Intent(Intent.ACTION_VIEW, Contacts.CONTENT_URI)
        startActivity(kontakteActivity)
    }
}
