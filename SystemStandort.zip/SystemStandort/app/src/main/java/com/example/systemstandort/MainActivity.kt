package com.example.systemstandort

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.systemstandort.databinding.ActivityMainBinding

import android.content.pm.PackageManager.PERMISSION_GRANTED
import android.Manifest
import androidx.core.app.ActivityCompat
import android.content.Context
import android.location.*

const val KONSTANTE_LOCATION = 123

class MainActivity : AppCompatActivity(),
        ActivityCompat.OnRequestPermissionsResultCallback {
    private lateinit var B: ActivityMainBinding

    private lateinit var lis:LocationListener
    private lateinit var man:LocationManager
    private var ausgabe = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        if(ActivityCompat.checkSelfPermission(this,
                        Manifest.permission.ACCESS_FINE_LOCATION) !=
                PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this,
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                    KONSTANTE_LOCATION)
        else
            standortDaten()
    }

    override fun onRequestPermissionsResult(
            requestCode: Int,
            permissions: Array<out String>,
            grantResults: IntArray) {
        if(requestCode == KONSTANTE_LOCATION &&
                grantResults.isNotEmpty() &&
                grantResults[0] == PERMISSION_GRANTED)
            standortDaten()
        else
            B.tvAusgabe.text = "Kein Recht für Standortdaten erteilt"
    }

    private fun standortDaten() {
        ausgabe += "Recht erteilt, gleich geht es los\n"
        B.tvAusgabe.text = ausgabe
        man = getSystemService(
                Context.LOCATION_SERVICE) as LocationManager

        lis = LocationListener { location ->
            val lt = (location.latitude * 1e4).toInt() / 1e4
            val ln = (location.longitude * 1e4).toInt() / 1e4
            ausgabe += "B: $lt, L: $ln\n"
            B.tvAusgabe.text = ausgabe
        }
    }

    override fun onResume() {
        super.onResume()
        if (ActivityCompat.checkSelfPermission(this,
                        Manifest.permission.ACCESS_FINE_LOCATION) ==
                PERMISSION_GRANTED) {
            man.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER, 2000, 0f, lis)
        }
    }

    override fun onPause() {
        super.onPause()
        if (ActivityCompat.checkSelfPermission(
                        this, Manifest.permission.ACCESS_FINE_LOCATION) ==
                PERMISSION_GRANTED) {
            man.removeUpdates(lis)
        }
    }
}
