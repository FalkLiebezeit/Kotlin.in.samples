package com.example.ereignisse

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.ereignisse.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        B.buDeutsch.setOnClickListener {
            B.tvAusgabe.text = "Guten Morgen"
        }

        B.buEnglisch.setOnClickListener {
            B.tvAusgabe.text = "Good morning"
        }
    }
}