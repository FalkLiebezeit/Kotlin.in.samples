package com.example.animationinterpolation

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.animationinterpolation.databinding.ActivityMainBinding

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.graphics.Path
import android.os.Build
import android.view.animation.*

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        val faktorDpToPx = resources.displayMetrics.density

        val va = ValueAnimator.ofFloat(0.0f, 340 * faktorDpToPx)
        va.interpolator = LinearInterpolator()
        va.duration = 3000L
        va.repeatMode = ObjectAnimator.REVERSE
        va.repeatCount = 1
        va.addUpdateListener { animation ->
            B.ivBild.translationY = animation.animatedValue as Float
        }

        B.buStart.setOnClickListener{
            if(!va.isStarted)
                va.start()
        }

        val pfad = Path()
        pfad.lineTo(0.4f, 0.05f)
        pfad.moveTo(0.4f, 0.5f)
        pfad.lineTo(1.0f, 1.0f)

        B.rgInterpolator.setOnCheckedChangeListener {_, checkedId ->
            va.repeatCount = 1
            when (checkedId) {
                B.rbAcc.id -> va.interpolator = AccelerateInterpolator()
                B.rbDec.id -> va.interpolator = DecelerateInterpolator()
                B.rbAccDec.id -> va.interpolator =
                    AccelerateDecelerateInterpolator()
                B.rbAnt.id -> va.interpolator = AnticipateInterpolator()
                B.rbOver.id -> va.interpolator = OvershootInterpolator()
                B.rbAntOver.id -> va.interpolator =
                    AnticipateOvershootInterpolator()
                B.rbBounce.id -> va.interpolator = BounceInterpolator()
                B.rbCycle.id -> {
                    va.repeatCount = 0
                    va.interpolator = CycleInterpolator(1.0f)
                }
                B.rbPath.id -> if (Build.VERSION.SDK_INT >= 21)
                    va.interpolator = PathInterpolator(pfad)
                B.rbLinear.id -> va.interpolator = LinearInterpolator()
            }
        }
    }
}
