package com.example.rechtegemeinsam

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.rechtegemeinsam.databinding.ActivityMainBinding

import android.content.pm.PackageManager.PERMISSION_GRANTED
import android.Manifest
import androidx.core.app.ActivityCompat

const val KONSTANTE_GEMEINSAM = 222

class MainActivity : AppCompatActivity(),
        ActivityCompat.OnRequestPermissionsResultCallback {
    private lateinit var B: ActivityMainBinding

    private val rechteArray = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.CAMERA,
            Manifest.permission.READ_CALENDAR,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.RECORD_AUDIO)

    private val rechteStringArray = arrayOf(
            "ACCESS_FINE_LOCATION", "CAMERA",
            "READ_CALENDAR", "READ_CONTACTS",
            "RECORD_AUDIO")

    private var ausgabe = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        var alleRechte = true
        for(berechtigung in rechteArray) {
            if(ActivityCompat.checkSelfPermission(
                            this, berechtigung) != PERMISSION_GRANTED) {
                alleRechte = false
                break
            }
        }

        if(!alleRechte)
            ActivityCompat.requestPermissions(
                    this, rechteArray, KONSTANTE_GEMEINSAM)
        else {
            ausgabe += "Alle Rechte sind vorhanden\n"
            aktionenAlle()
        }
    }

    override fun onRequestPermissionsResult(
            requestCode: Int,
            permissions: Array<out String>,
            grantResults: IntArray) {
        var rechteZaehler = 0
        if(requestCode == KONSTANTE_GEMEINSAM
                && grantResults.isNotEmpty()) {
            for(i in grantResults.indices) {
                if (grantResults[i] == PERMISSION_GRANTED) {
                    ausgabe += rechteStringArray[i] +
                            ", Recht vorhanden\n"
                    rechteZaehler++
                }
                else
                    ausgabe += rechteStringArray[i] +
                            ", Recht nicht vorhanden\n"
            }
        }

        if(rechteZaehler == grantResults.size) {
            ausgabe += "Alle Rechte wurden erteilt\n"
            aktionenAlle()
        }
        else {
            ausgabe += "Es wurden nicht alle Rechte erteilt"
            B.tvAusgabe.text = ausgabe
        }
    }

    private fun aktionenAlle() {
        ausgabe += "Es kann losgehen"
        B.tvAusgabe.text = ausgabe
    }
}
