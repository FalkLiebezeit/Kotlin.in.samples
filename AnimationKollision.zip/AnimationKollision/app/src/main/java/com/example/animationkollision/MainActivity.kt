package com.example.animationkollision

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.animation.ValueAnimator
import android.graphics.Rect
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import com.example.animationkollision.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        val faktorDpToPx = resources.displayMetrics.density
        val rectZwei = rechteck(B.ivBildZwei)

        val va = ValueAnimator.ofFloat(0.0f, 300 * faktorDpToPx)
        va.duration = 3000L
        va.interpolator = LinearInterpolator()
        va.addUpdateListener { animation ->
            val av = animation.animatedValue as Float
            B.ivBildEins.translationY = av
            val rectEins = rechteck(B.ivBildEins)
            if(rectEins.intersect(rectZwei))
                va.cancel()
        }

        B.buStart.setOnClickListener{
            if(!va.isStarted)
                va.start()
        }
    }

    private fun rechteck(v: View): Rect {
        val posPx = v.layoutParams as ViewGroup.MarginLayoutParams
        val grPx = v.layoutParams
        return Rect(
                (posPx.leftMargin + v.translationX).toInt(),
                (posPx.topMargin + v.translationY).toInt(),
                (posPx.leftMargin + v.translationX +
                        grPx.width).toInt(),
                (posPx.topMargin + v.translationY +
                        grPx.height).toInt())
    }
}
