package com.example.quadrate

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.FrameLayout
import android.widget.ImageView
import java.util.Calendar
import kotlin.random.Random
import com.example.quadrate.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        // Alle Farben
        val farbeArray = intArrayOf(
                R.drawable.rot, R.drawable.gelb,
                R.drawable.gruen, R.drawable.blau,
                R.drawable.cyan, R.drawable.ocker)

        // Einstellungen für Ziel
        var farbeZiel = R.drawable.rot
        var ziel = B.ivZiel

        // Einstellungen für Zeit
        val zeitStart = Calendar.getInstance().time.time
        var spielAktiv = true

        val breite = resources.displayMetrics.widthPixels
        val hoehe = resources.displayMetrics.heightPixels
        var punkte = 0

        // Neues Quadrat erzeugen
        val neuHandler = Handler(Looper.getMainLooper())
        val neuObjekt = object:Runnable {
            override fun run() {
                val ivNeu = ImageView(this@MainActivity)
                val farbe = farbeArray.random()
                ivNeu.tag = farbe
                ivNeu.setImageResource(farbe)

                val lp = FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.WRAP_CONTENT,
                        FrameLayout.LayoutParams.WRAP_CONTENT)
                lp.leftMargin = (Random.nextDouble(0.05, 0.8)
                        * breite).toInt()
                lp.topMargin = (Random.nextDouble(0.05, 0.8)
                        * hoehe).toInt()
                ivNeu.layoutParams = lp
                B.flGesamt.addView(ivNeu)

                // Punkte zählen
                ivNeu.setOnClickListener {
                    B.flGesamt.removeView(ivNeu)
                    if(spielAktiv) {
                        punkte += if (ivNeu.tag == farbeZiel) 1 else -1
                        B.tvPunkte.text = "Punkte: $punkte"
                    }
                }

                // Neues Quadrat in 5 sec. löschen
                val loeschHandler = Handler(Looper.getMainLooper())
                val loeschObjekt = object:Runnable {
                    override fun run() {
                        B.flGesamt.removeView(ivNeu)
                    }
                }
                loeschHandler.postDelayed(loeschObjekt, 5000L)

                // Nächstes Quadrat erzeugen
                neuHandler.postDelayed(this, 500L)
            }
        }
        // Erstes Quadrat erzeugen
        neuHandler.postDelayed(neuObjekt, 500L)

        // Zielfarbe ändern
        val zielHandler = Handler(Looper.getMainLooper())
        val zielObjekt = object:Runnable {
            override fun run() {
                val farbeZielAlt = farbeZiel
                while(farbeZielAlt == farbeZiel)
                    farbeZiel = farbeArray.random()

                // Altes Ziel löschen
                B.flGesamt.removeView(ziel)

                // Neues Ziel erzeugen
                ziel = ImageView(this@MainActivity)
                ziel.setImageResource(farbeZiel)
                val lp = FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.WRAP_CONTENT,
                        FrameLayout.LayoutParams.WRAP_CONTENT)
                ziel.layoutParams = lp
                B.flGesamt.addView(ziel)

                // Nächstes Ziel erzeugen
                zielHandler.postDelayed(this, 5000L)
            }
        }
        zielHandler.postDelayed(zielObjekt, 5000L)

        // Zeitanzeige aktualisieren
        val zeitHandler = Handler(Looper.getMainLooper())
        val zeitObjekt = object:Runnable {
            override fun run() {
                val zeitAktuell = Calendar.getInstance().time.time
                val zeitDifferenz = zeitAktuell - zeitStart
                val zeitAusgabe = 60 - zeitDifferenz / 1000
                B.tvZeit.text = "$zeitAusgabe sec."

                if(zeitDifferenz > 60000L) {
                    spielAktiv = false
                    neuHandler.removeCallbacks(neuObjekt)
                    zielHandler.removeCallbacks(zielObjekt)
                }
                else
                    zeitHandler.postDelayed(this, 1000L)
            }
        }
        zeitHandler.postDelayed(zeitObjekt, 1000L)
    }
}
