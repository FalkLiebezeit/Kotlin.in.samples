package com.example.dialoge

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.dialoge.databinding.ActivityMainBinding

import android.app.AlertDialog
import android.widget.EditText
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        B.buToast.setOnClickListener {
            val t1 = Toast.makeText(this, "Toast 1", Toast.LENGTH_LONG)
            t1.show()
            val t2 = Toast.makeText(this, "Toast 2", Toast.LENGTH_LONG)
            t2.show()
        }

        B.buSnackbar.setOnClickListener {
            val s1 = Snackbar.make(it, "Snackbar 1", Snackbar.LENGTH_LONG)
            s1.show()
            val s2 = Snackbar.make(it, "Snackbar 2", Snackbar.LENGTH_LONG)
            s2.show()
        }

        B.buInfo.setOnClickListener {
            val meldung = AlertDialog.Builder(this)
            meldung.setMessage("Haben Sie das gelesen?")
            meldung.setPositiveButton("Ja") { _, _ ->
                B.tvAusgabe.text = "Sie haben es gelesen"
            }
            meldung.show()
        }

        B.buFrage.setOnClickListener {
            val meldung = AlertDialog.Builder(this)
            meldung.setMessage("Möchten Sie spielen?")
            meldung.setTitle("Monopoly")
            meldung.setIcon(R.drawable.rheinwerk)
            meldung.setPositiveButton("Ja") { _, _ ->
                B.tvAusgabe.text = "Sie möchten spielen"
            }
            meldung.setNegativeButton("Nein") { _, _ ->
                B.tvAusgabe.text = "Sie möchten nicht spielen"
            }
            meldung.setNeutralButton("Abbrechen") { _, _ ->
                B.tvAusgabe.text = "Sie haben die Frage abgebrochen"
            }
            meldung.show()
        }

        B.buEingabe.setOnClickListener {
            val etNeu = EditText(this)
            etNeu.setText("Ihre Eingabe")

            val meldung = AlertDialog.Builder(this)
            meldung.setMessage("Ihre Eingabe:")
            meldung.setPositiveButton("Speichern") { _, _ ->
                B.tvAusgabe.text = "Eingabe: ${etNeu.text}"
            }
            meldung.setNegativeButton("Abbrechen") { _, _ ->
                B.tvAusgabe.text = "Eingabe abgebrochen"
            }
            meldung.setView(etNeu)
            meldung.show()
        }
    }
}
