package com.example.menuekontext

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import com.example.menuekontext.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        B.buHilfe.setOnCreateContextMenuListener {
            menu, view, menuInfo ->
            super.onCreateContextMenu(menu, view, menuInfo)
            menuInflater.inflate(R.menu.hilfe, menu)
        }

        B.buInfo.setOnCreateContextMenuListener {
            menu, view, menuInfo ->
            super.onCreateContextMenu(menu, view, menuInfo)
            menuInflater.inflate(R.menu.info, menu)
        }
    }

    override fun onContextItemSelected(
            item: MenuItem): Boolean {
        when(item.itemId) {
            R.id.itHilfeEins -> B.tvAusgabe.text = "Hilfe Eins"
            R.id.itHilfeZwei -> B.tvAusgabe.text = "Hilfe Zwei"
            R.id.itHilfeDrei -> B.tvAusgabe.text = "Hilfe Drei"
            R.id.itInfoEins -> B.tvAusgabe.text = "Info Eins"
            R.id.itInfoZwei -> B.tvAusgabe.text = "Info Zwei"
        }
        return true
    }
}
