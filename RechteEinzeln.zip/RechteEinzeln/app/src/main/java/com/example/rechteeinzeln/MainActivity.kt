package com.example.rechteeinzeln

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.rechteeinzeln.databinding.ActivityMainBinding

import android.content.pm.PackageManager.PERMISSION_GRANTED
import android.Manifest
import androidx.core.app.ActivityCompat

const val KONSTANTE_CAMERA = 111

class MainActivity : AppCompatActivity(),
        ActivityCompat.OnRequestPermissionsResultCallback {
    private lateinit var B: ActivityMainBinding
    private var ausgabe = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        val rechtCamera = ActivityCompat.checkSelfPermission(
                        this, Manifest.permission.CAMERA)

        if(rechtCamera == PERMISSION_GRANTED) {
            ausgabe = "CAMERA, Recht vorhanden\n"
            aktionenCamera()
        }
        else {
            ausgabe = "CAMERA, Recht nicht vorhanden\n"
            ActivityCompat.requestPermissions(this,
                    arrayOf(Manifest.permission.CAMERA),
                    KONSTANTE_CAMERA)
        }
    }

    override fun onRequestPermissionsResult(
            requestCode: Int,
            permissions: Array<out String>,
            grantResults: IntArray) {
        if(requestCode == KONSTANTE_CAMERA
                && grantResults.isNotEmpty()
                && grantResults[0] == PERMISSION_GRANTED) {
            ausgabe += "CAMERA, Recht erteilt\n"
            aktionenCamera()
        }
        else {
            ausgabe += "CAMERA, Recht nicht erteilt"
            B.tvAusgabe.text = ausgabe
        }
    }

    private fun aktionenCamera() {
        ausgabe += "Es kann losgehen"
        B.tvAusgabe.text = ausgabe
    }
}
