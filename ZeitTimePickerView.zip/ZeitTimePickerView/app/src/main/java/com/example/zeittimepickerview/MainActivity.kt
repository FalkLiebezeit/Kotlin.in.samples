package com.example.zeittimepickerview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.zeittimepickerview.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        val sdf = SimpleDateFormat(
                "HH:mm", Locale.getDefault())

        val kal = Calendar.getInstance()
        var ausgabe = "Uhrzeit: " + sdf.format(kal.time)
        B.tvUhrzeit.text = ausgabe

        B.tpUhrzeit.setIs24HourView(true)

        B.tpUhrzeit.setOnTimeChangedListener {
                _, hourOfDay, minute ->
            val kalAuswahl = Calendar.getInstance()
            kalAuswahl.set(Calendar.HOUR_OF_DAY, hourOfDay)
            kalAuswahl.set(Calendar.MINUTE, minute)
            ausgabe = "Uhrzeit: " + sdf.format(kalAuswahl.time)
            B.tvUhrzeit.text = ausgabe
        }
    }
}
