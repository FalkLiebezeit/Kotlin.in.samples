package com.example.sensorenumgebung

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Context
import android.hardware.*
import com.example.sensorenumgebung.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding

    private lateinit var sMan: SensorManager
    private lateinit var horcher: SensorEventListener

    private var licht: Sensor? = null
    private var temperatur: Sensor? = null
    private var druck: Sensor? = null
    private var feuchte: Sensor? = null
    private var naehe: Sensor? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        sMan = getSystemService(
                Context.SENSOR_SERVICE) as SensorManager

        licht = sMan.getDefaultSensor(Sensor.TYPE_LIGHT)
        if (licht == null)
            B.tvLicht.text = "Kein Lichtsensor"

        temperatur = sMan.getDefaultSensor(
                Sensor.TYPE_AMBIENT_TEMPERATURE)
        if (temperatur == null)
            B.tvTemperatur.text = "Kein Sensor für Temperatur"

        druck = sMan.getDefaultSensor(
                Sensor.TYPE_PRESSURE)
        if (druck == null)
            B.tvDruck.text = "Kein Sensor für Druck"

        feuchte = sMan.getDefaultSensor(
                Sensor.TYPE_RELATIVE_HUMIDITY)
        if (feuchte == null)
            B.tvFeuchte.text = "Kein Sensor für Feuchte"

        naehe = sMan.getDefaultSensor(
                Sensor.TYPE_PROXIMITY)
        if (naehe == null)
            B.tvNaehe.text = "Kein Sensor für Nähe"

        horcher = object:SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                when(event.sensor?.type) {
                    Sensor.TYPE_LIGHT -> {
                        val licht = (event.values[0] * 10).toInt() / 10.0f
                        B.tvLicht.text = "Licht: $licht lx"
                    }
                    Sensor.TYPE_AMBIENT_TEMPERATURE -> {
                        val temp = (event.values[0] * 10).toInt() / 10.0f
                        B.tvTemperatur.text = "Temperatur: $temp Grad Celsius"
                    }
                    Sensor.TYPE_PRESSURE -> {
                        val druck = (event.values[0] * 10).toInt() / 10.0f
                        B.tvDruck.text = "Druck: $druck hPa"
                    }
                    Sensor.TYPE_RELATIVE_HUMIDITY -> {
                        val feuchte = (event.values[0] * 10).toInt() / 10.0f
                        B.tvFeuchte.text = "Feuchte: $feuchte %"
                    }
                    Sensor.TYPE_PROXIMITY -> {
                        val naehe = (event.values[0] * 10).toInt() / 10.0f
                        B.tvNaehe.text = "Nähe: $naehe cm"
                    }
                }
            }

            override fun onAccuracyChanged(
                    sensor: Sensor?, accuracy: Int) {
            }
        }
    }

    override fun onPause() {
        super.onPause()
        sMan.unregisterListener(horcher)
    }

    override fun onResume() {
        super.onResume()
        sMan.registerListener(horcher, licht,
                SensorManager.SENSOR_DELAY_NORMAL)
        sMan.registerListener(horcher, temperatur,
                SensorManager.SENSOR_DELAY_NORMAL)
        sMan.registerListener(horcher, druck,
                SensorManager.SENSOR_DELAY_NORMAL)
        sMan.registerListener(horcher, feuchte,
                SensorManager.SENSOR_DELAY_NORMAL)
        sMan.registerListener(horcher, naehe,
                SensorManager.SENSOR_DELAY_NORMAL)
    }
}
