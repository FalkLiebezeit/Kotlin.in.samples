package com.example.listenervarianten

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import com.example.listenervarianten.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(), View.OnClickListener {
    private lateinit var B: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        B.buEins.setOnClickListener(this)
        B.buZwei.setOnClickListener(this)

        val mDrei = MeineListenerKlasse()
        B.buDrei.setOnClickListener(mDrei)

        B.buVier.setOnClickListener(MeinListenerObjekt)

        val mFuenf = object: View.OnClickListener {
            override fun onClick(v: View?) {
                B.tvAusgabe.text = "5"
            }
        }
        B.buFuenf.setOnClickListener(mFuenf)

        B.buSechs.setOnClickListener(object: View.OnClickListener {
            override fun onClick(v: View?) {
                B.tvAusgabe.text = "6"
            }
        })

        B.buSieben.setOnClickListener { v ->
            val bu = v as Button
            bu.text = "Sieben"
        }

        B.buAcht.setOnClickListener { _ ->
            B.tvAusgabe.text = "8"
        }

        B.buNeun.setOnClickListener {
            val bu = it as Button
            bu.text = "Neun"
        }

        B.buZehn.setOnClickListener {
            B.tvAusgabe.text = "10"
        }
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            B.buEins.id -> B.tvAusgabe.text = "1"
            B.buZwei.id -> B.tvAusgabe.text = "2"
        }
    }
}
