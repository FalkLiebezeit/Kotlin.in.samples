package com.example.listenervarianten

import android.view.View
import android.widget.Button

class MeineListenerKlasse: View.OnClickListener {
    override fun onClick(v: View?) {
        val bu = v as Button
        bu.text = "Drei"
    }
}
