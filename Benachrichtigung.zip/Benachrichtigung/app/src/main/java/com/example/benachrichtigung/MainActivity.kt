package com.example.benachrichtigung

import android.app.*
import android.content.*
import android.os.Build
import android.os.Bundle
import android.widget.RemoteViews
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import com.example.benachrichtigung.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding
    private lateinit var nachrichtenManager: NotificationManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        nachrichtenManager = getSystemService(
            Context.NOTIFICATION_SERVICE) as NotificationManager

        B.buSenden.setOnClickListener {
            val aktionsAbsicht = Intent(this,
                WichtigeActivity::class.java)
            val aktionsInhalt = PendingIntent.getActivity(
                this, 0, aktionsAbsicht,
                PendingIntent.FLAG_UPDATE_CURRENT)
            val wichtigOberflaeche = RemoteViews(
                packageName, R.layout.activity_wichtige)

            if (Build.VERSION.SDK_INT >= 26) {
                val nachrichtenKanal = NotificationChannel(
                    "kanalID1", "nachricht",
                    NotificationManager.IMPORTANCE_HIGH)
                nachrichtenManager.createNotificationChannel(
                    nachrichtenKanal)
            }

            val nachrichtenErsteller = NotificationCompat.Builder(
                this, "kanalID1")
                .setContent(wichtigOberflaeche)
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setContentIntent(aktionsInhalt)
            val nachricht = nachrichtenErsteller.build()
            nachrichtenManager.notify(1234, nachricht)
        }
    }
}
