package com.example.zeitcalendarview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.zeitcalendarview.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        val sdf = SimpleDateFormat(
                "dd.MM.yyyy", Locale.getDefault())

        val kal = Calendar.getInstance()
        kal.set(2021, 6, 15)
        B.cvDatum.date = kal.timeInMillis
        var ausgabe = "Datum: " + sdf.format(kal.time)
        B.tvDatum.text = ausgabe

        kal.set(2021, 5, 20)
        B.cvDatum.minDate = kal.timeInMillis
        kal.set(2021, 7, 10)
        B.cvDatum.maxDate = kal.timeInMillis

        B.cvDatum.setOnDateChangeListener {
            _, year, month, dayOfMonth ->
            val kalAuswahl = Calendar.getInstance()
            kalAuswahl.set(year, month, dayOfMonth)
            ausgabe = "Datum: " + sdf.format(kalAuswahl.time)
            B.tvDatum.text = ausgabe
        }
    }
}
