package com.example.systemkalender

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.provider.CalendarContract
import android.provider.CalendarContract.Events
import java.util.Calendar

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val ev = Intent(Intent.ACTION_INSERT, Events.CONTENT_URI)
        ev.putExtra(Events.TITLE, "Treffen mit Interessenten")
        ev.putExtra(Events.DESCRIPTION, "Präsentation vorbereiten")
        ev.putExtra(Events.EVENT_LOCATION, "Bonn")

        val k = Calendar.getInstance()
        k.set(2021, 11, 20, 15, 30)
        ev.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, k.time.time)
        k.set(2021, 11, 20, 16, 15)
        ev.putExtra(CalendarContract.EXTRA_EVENT_END_TIME, k.time.time)

        startActivity(ev)
        finish()
    }
}
