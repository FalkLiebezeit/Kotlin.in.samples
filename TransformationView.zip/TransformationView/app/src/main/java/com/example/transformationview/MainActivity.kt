package com.example.transformationview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Build
import androidx.core.content.ContextCompat
import com.example.transformationview.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding
    private var faktorDpToPx = 0.0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        faktorDpToPx = resources.displayMetrics.density

        B.buTXPlus.setOnClickListener{ verschieben(50, 0, 0) }
        B.buTXMinus.setOnClickListener{ verschieben(-50, 0, 0) }
        B.buTYPlus.setOnClickListener{ verschieben(0, 30, 0) }
        B.buTYMinus.setOnClickListener{ verschieben(0, -30, 0)}
        B.buTZPlus.setOnClickListener{ verschieben(0, 0, 50) }
        B.buTZMinus.setOnClickListener{ verschieben(0, 0, -50) }

        B.buSXPlus.setOnClickListener{ skalieren(0.1f, 0.0f) }
        B.buSXMinus.setOnClickListener{ skalieren(-0.1f, 0.0f)}
        B.buSYPlus.setOnClickListener{ skalieren(0.0f, 0.1f) }
        B.buSYMinus.setOnClickListener{ skalieren(0.0f, -0.1f) }

        B.buRXPlus.setOnClickListener{ drehen(30.0f, 0.0f, 0.0f) }
        B.buRXMinus.setOnClickListener{ drehen(-30.0f, 0.0f, 0.0f) }
        B.buRYPlus.setOnClickListener{ drehen(0.0f, 30.0f, 0.0f) }
        B.buRYMinus.setOnClickListener{ drehen(0.0f, -30.0f, 0.0f) }
        B.buRZPlus.setOnClickListener{ drehen(0.0f, 0.0f, 10.0f) }
        B.buRZMinus.setOnClickListener{ drehen(0.0f, 0.0f, -10.0f) }

        B.buFarbe.setOnClickListener {
            val farbe = ContextCompat.getColor(this, R.color.hellgrau)
            B.lyBilder.setBackgroundColor(farbe)
        }
    }

    private fun verschieben(xDeltaDp:Int, yDeltaDp:Int,
                            zDeltaDp:Int) {
        B.ivBildT.translationX += xDeltaDp * faktorDpToPx
        B.ivBildT.translationY += yDeltaDp * faktorDpToPx
        val x = B.ivBildT.translationX.toInt()
        val y = B.ivBildT.translationY.toInt()

        if (Build.VERSION.SDK_INT >= 21) {
            B.ivBildT.translationZ += zDeltaDp * faktorDpToPx
            val z = B.ivBildT.translationZ.toInt()
            B.tvAusgabe.text =
                "Translation X: $x px, Y: $y px, Z: $z px"
        }
        else
            B.tvAusgabe.text = "Translation X: $x px, Y: $y px"
    }

    private fun skalieren(xDelta:Float, yDelta:Float) {
        B.ivBildS.scaleX += xDelta
        B.ivBildS.scaleY += yDelta
        val x = (B.ivBildS.scaleX * 10).toInt() / 10.0
        val y = (B.ivBildS.scaleY * 10).toInt() / 10.0
        B.tvAusgabe.text = "Scale X: $x, Y: $y"
    }

    private fun drehen(xDelta:Float, yDelta:Float, zDelta:Float) {
        B.ivBildR.rotationX += xDelta
        B.ivBildR.rotationY += yDelta
        B.ivBildR.rotation += zDelta
        val x = B.ivBildR.rotationX.toInt()
        val y = B.ivBildR.rotationY.toInt()
        val z = B.ivBildR.rotation.toInt()
        B.tvAusgabe.text = "Rotation X: $x, Y: $y, Z: $z"
    }
}
