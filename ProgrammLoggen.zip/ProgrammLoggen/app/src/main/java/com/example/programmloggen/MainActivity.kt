package com.example.programmloggen

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.example.programmloggen.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding
    private var ausgabe = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        for(zahl in 1 .. 6) {
            Log.d("onCreate()", "Zahl: $zahl")
            ausgeben(zahl)
        }
        B.tvAusgabe.text = ausgabe
    }

    private fun ausgeben(z:Int) {
        if(z % 2 == 0) {
            Log.d("ausgeben()", "% == 0")
            ausgebenGerade()
        }
        else {
            Log.d("ausgeben()", "% != 0")
            ausgebenUngerade()
        }
    }

    private fun ausgebenGerade() {
        Log.d("ausgebenGerade()", "gerade")
        ausgabe += "gerade\n"
    }

    private fun ausgebenUngerade() {
        Log.d("ausgebenUngerade()", "ungerade")
        ausgabe += "ungerade\n"
    }
}