package com.example.bild

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.bild.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        B.ibBild.setOnClickListener {
            B.ivBild.setImageResource(R.drawable.android)
            B.ibBild.setImageResource(R.drawable.android)
        }
    }
}
