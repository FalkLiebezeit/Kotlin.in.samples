package com.example.speicherntextdateien

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Context
import java.io.*
import com.example.speicherntextdateien.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        B.buSchreiben.setOnClickListener {
            val z = 42
            val x = 47.11
            val t = "Hallo Welt"
            val datei = openFileOutput("daten.txt", Context.MODE_PRIVATE)
            val schreiber = OutputStreamWriter(datei)
            schreiber.write("$z\n$x\n$t\n")
            schreiber.close()
            datei.close()

            B.tvAusgabe.text = "Geschrieben"
        }

        B.buAnhaengen.setOnClickListener {
            val datei = openFileOutput("daten.txt", Context.MODE_APPEND)
            val schreiber = OutputStreamWriter(datei)
            schreiber.write("Nächste Zeile\n")
            schreiber.close()
            datei.close()

            B.tvAusgabe.text = "Angehängt"
        }

        B.buLeeren.setOnClickListener {
            val datei = openFileOutput("daten.txt", Context.MODE_PRIVATE)
            val schreiber = OutputStreamWriter(datei)
            schreiber.write("")
            schreiber.close()
            datei.close()

            B.tvAusgabe.text = "Geleert"
        }

        B.buLesenGesamt.setOnClickListener {
            var ausgabe = ""
            try {
                val datei = openFileInput("daten.txt")
                val leser = InputStreamReader(datei)
                ausgabe = leser.readText()
                if (ausgabe.isEmpty())
                    ausgabe = "(Datei ist leer)"
                leser.close()
                datei.close()
            }
            catch(ex:Exception) {
                ausgabe = "(Fehler beim Lesen)"
            }
            B.tvAusgabe.text = ausgabe
        }

        B.buLesenZeilen.setOnClickListener {
            var ausgabe = ""
            try {
                val datei = openFileInput("daten.txt")
                val leser = InputStreamReader(datei)
                val liste = leser.readLines()
                ausgabe += "Anzahl: ${liste.size}\n"
                for(x in liste.indices)
                    ausgabe += "$x: ${liste[x]}\n"
                leser.close()
                datei.close()
            }
            catch(ex:Exception) {
                ausgabe = "(Fehler beim Lesen)"
            }
            B.tvAusgabe.text = ausgabe
        }
    }
}
