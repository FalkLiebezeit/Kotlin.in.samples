package com.example.gestewischen

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MotionEvent
import java.util.*
import kotlin.math.*
import com.example.gestewischen.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        var xDownPx = 0.0f
        var yDownPx = 0.0f
        val minDeltaPx = 20.0f

        var zeitDownMs = 0L
        val zeitGrenzeMs = 500L

        B.ivBild.setOnTouchListener { view, event ->
            if(event.action == MotionEvent.ACTION_DOWN) {
                xDownPx = event.x
                yDownPx = event.y
                zeitDownMs = Calendar.getInstance().time.time
            }
            else if(event.action == MotionEvent.ACTION_UP) {
                val zeitUpMs = Calendar.getInstance().time.time
                val zeitDeltaMs = zeitUpMs - zeitDownMs

                val xDeltaPx = event.x - xDownPx
                val yDeltaPx = event.y - yDownPx

                val xAbsDeltaPx = xDeltaPx.absoluteValue
                val yAbsDeltaPx = yDeltaPx.absoluteValue

                var geschwindigkeit = ""
                var aktion = ""

                if (xAbsDeltaPx < minDeltaPx
                        && yAbsDeltaPx < minDeltaPx) {
                    geschwindigkeit = ""
                    aktion = "Getippt"
                } else {
                    geschwindigkeit = if (zeitDeltaMs > zeitGrenzeMs)
                        "Langsam " else "Schnell "
                    aktion = if (xAbsDeltaPx > yAbsDeltaPx)
                        if (xDeltaPx > 0)
                            "nach rechts" else "nach links"
                    else
                        if (yDeltaPx > 0)
                            "nach unten" else "nach oben"
                }

                val ausgabe = geschwindigkeit + aktion
                B.tvAusgabe.text = ausgabe
            }
            view.performClick()
            true
        }
    }
}
