package com.example.zeitsteuerungmehrere

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.zeitsteuerungmehrere.databinding.ActivityMainBinding
import android.os.Handler
import android.os.Looper

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        val steuerungEins = Handler(Looper.getMainLooper())
        val steuerungZwei = Handler(Looper.getMainLooper())
        var ausgabe = ""

        val ereignisEins = object:Runnable {
            override fun run() {
                ausgabe += "1 "
                B.tvAusgabe.text = ausgabe
                steuerungEins.postDelayed(this, 500L)
            }
        }

        B.buEins.setOnClickListener {
            B.buEins.isEnabled = false
            steuerungEins.postDelayed(ereignisEins, 0L)
        }

        val ereignisZwei = object:Runnable {
            override fun run() {
                ausgabe += "2 "
                B.tvAusgabe.text = ausgabe
                steuerungZwei.postDelayed(this, 300L)
            }
        }

        B.buZwei.setOnClickListener {
            B.buZwei.isEnabled = false
            steuerungZwei.postDelayed(ereignisZwei, 0L)
        }
    }
}
