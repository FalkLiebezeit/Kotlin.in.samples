package com.example.animationview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.animationview.databinding.ActivityMainBinding

import android.animation.ValueAnimator
import android.animation.ObjectAnimator
import android.os.Build
import android.view.animation.LinearInterpolator

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        val faktorDpToPx = resources.displayMetrics.density

        val va = ValueAnimator.ofFloat(0.0f, 300 * faktorDpToPx)
        va.startDelay = 500L
        va.duration = 3000L
        va.repeatCount = 1
        va.repeatMode = ObjectAnimator.REVERSE
        va.interpolator = LinearInterpolator()

        va.addUpdateListener { animation ->
            val av = animation.animatedValue as Float
            B.ivBild.translationX = av
            B.ivBild.translationY = av * 100 / (300 * faktorDpToPx)
            B.ivBild.rotation = av * 180 / (300 * faktorDpToPx)
            B.ivBild.scaleX = 1 - (av * 0.8f / (300 * faktorDpToPx))
            B.tvWert.text = "${av.toInt()} px"
            B.tvZeit.text = "${animation.currentPlayTime} msec."
        }

        B.buStart.setOnClickListener {
            if(!va.isStarted)
                va.start()
        }

        B.buEnd.setOnClickListener {
            va.end()
            B.tvWert.text = "0 px"
            B.tvZeit.text = "0 msec."
        }

        B.buCancel.setOnClickListener {
            va.cancel()
        }

        B.buPause.setOnClickListener{
            if (Build.VERSION.SDK_INT >= 19)
                va.pause()
        }

        B.buResume.setOnClickListener{
            if (Build.VERSION.SDK_INT >= 19)
                va.resume()
        }
    }
}
