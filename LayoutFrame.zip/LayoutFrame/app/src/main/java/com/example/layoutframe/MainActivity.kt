package com.example.layoutframe

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.FrameLayout
import android.widget.ImageView
import kotlin.random.Random
import com.example.layoutframe.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        val breite = resources.displayMetrics.widthPixels
        val hoehe = resources.displayMetrics.heightPixels
        var zaehler = 0

        B.buNeu.setOnClickListener {
            val ivNeu = ImageView(this)
            B.flGesamt.addView(ivNeu)
            ivNeu.setImageResource(R.drawable.gruen)
            ivNeu.setOnClickListener { view ->
                B.tvAusgabe.text = view.tag.toString()
            }

            zaehler++
            ivNeu.tag = zaehler

            val lp = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT)
            lp.leftMargin = (Random.nextDouble(0.05,0.85)
                    * breite).toInt()
            lp.topMargin = (Random.nextDouble(0.05,0.85)
                    * hoehe).toInt()
            ivNeu.layoutParams = lp
        }

        B.ivBild0.setOnClickListener { view ->
            B.tvAusgabe.text = view.tag.toString()
        }
    }
}