package com.example.speicherndatenbanken

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatenbankKlasse(context: Context):
    SQLiteOpenHelper(context, "highscore.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE [highscore]" +
                " ([id] INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                "[vorname] TEXT NOT NULL, [wert] INTEGER NOT NULL)")
    }

    override fun onUpgrade(db: SQLiteDatabase,
                           versionAlt: Int, versionNeu: Int) {
    }
}