package com.example.speicherndatenbanken

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.ContentValues
import kotlin.random.Random
import com.example.speicherndatenbanken.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding
    private val datenbank = DatenbankKlasse(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        val arVorname =
                arrayOf("Sonja", "Bernd", "Monika", "Paul")

        B.buSchreiben.setOnClickListener {
            val schreiber = datenbank.writableDatabase
            val datensatz = ContentValues()
            val ausgabe:String

            datensatz.put("vorname", arVorname.random())
            datensatz.put("wert", Random.nextInt(20))
            ausgabe = if(schreiber.insert(
                    "highscore", null, datensatz) == -1L)
                            "Fehler beim Hinzufügen"
                        else
                            "Datensatz hinzugefügt"

            B.tvAusgabe.text = ausgabe
            schreiber.close()
            lesen()
        }

        B.buLesen.setOnClickListener {
            B.tvAusgabe.text = ""
            lesen()
            B.tvAusgabe.text = "Alle Datensätze gelesen"
        }

        B.buAendern.setOnClickListener{
            val schreiber = datenbank.writableDatabase
            val datensatz = ContentValues()

            datensatz.put("wert", 22)
            val anzahl = schreiber.update(
                    "highscore", datensatz, "vorname='Bernd'", null)
            val ausgabe = "Anzahl geändert: $anzahl"

            B.tvAusgabe.text = ausgabe
            schreiber.close()
            lesen()
        }

        B.buLoeschenAuswahl.setOnClickListener {
            val schreiber = datenbank.writableDatabase

            val anzahl = schreiber.delete(
                    "highscore", "wert > 10", null)
            val ausgabe = "Anzahl gelöscht: $anzahl"

            B.tvAusgabe.text = ausgabe
            schreiber.close()
            lesen()
        }

        B.buLoeschenAlle.setOnClickListener {
            val schreiber = datenbank.writableDatabase

            val anzahl = schreiber.delete("highscore", "", null)
            val ausgabe = "Anzahl gelöscht: $anzahl"

            B.tvAusgabe.text = ausgabe
            schreiber.close()
            lesen()
        }
    }

    private fun lesen() {
        val leser = datenbank.readableDatabase
        var daten = ""

        val ergebnis = leser.rawQuery(
                "SELECT * FROM highscore ORDER BY wert DESC", null)
        if (ergebnis.count == 0)
            daten += "(Keine Datensätze)"
        else {
            while(ergebnis.moveToNext()) {
                var x = ergebnis.getColumnIndex("id")
                val id = if(x == -1) 0 else ergebnis.getInt(x)
                x = ergebnis.getColumnIndex("vorname")
                val vorname = if(x == -1) "" else ergebnis.getString(x)
                x = ergebnis.getColumnIndex("wert")
                val wert = if(x == -1) 0 else ergebnis.getInt(x)
                daten += "id $id $vorname $wert\n"
            }
        }

        B.tvDaten.text = daten
        ergebnis.close()
        leser.close()
    }

    override fun onStop() {
        super.onStop()
        datenbank.close()
    }
}
