package com.example.sensorenlage

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Context
import android.hardware.*
import kotlin.math.*
import com.example.sensorenlage.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var B: ActivityMainBinding
    private lateinit var sMan: SensorManager

    private var accSensor: Sensor? = null
    private var gyrSensor: Sensor? = null
    private var magSensor: Sensor? = null

    private lateinit var accHorcher: SensorEventListener
    private lateinit var gyrHorcher: SensorEventListener
    private lateinit var magHorcher: SensorEventListener

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        B = ActivityMainBinding.inflate(layoutInflater)
        setContentView(B.root)

        sMan = getSystemService(
                Context.SENSOR_SERVICE) as SensorManager

        accSensor =
                sMan.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if(accSensor == null)
            B.tvAcc.text = "Kein Sensor für lineare Beschleunigung"

        gyrSensor =
                sMan.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        if(gyrSensor == null)
            B.tvGyr.text = "Kein Sensor für Drehbeschleunigung"

        magSensor =
                sMan.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        if(magSensor == null)
            B.tvGyr.text = "Kein Sensor für Magnetfeld"

        var accXMax = 0.0f
        var accYMax = 0.0f
        var accZMax = 0.0f

        accHorcher = object:SensorEventListener{
            override fun onSensorChanged(event: SensorEvent?) {
                if (event == null) return

                val accX = (event.values[0].absoluteValue * 10).toInt() / 10.0f
                val accY = (event.values[1].absoluteValue * 10).toInt() / 10.0f
                val accZ = (event.values[2].absoluteValue * 10).toInt() / 10.0f

                accXMax = max(accX, accXMax)
                accYMax = max(accY, accYMax)
                accZMax = max(accZ, accZMax)

                B.tvAccX.text = "X: $accXMax / $accX"
                B.tvAccY.text = "Y: $accYMax / $accY"
                B.tvAccZ.text = "Z: $accZMax / $accZ"
            }

            override fun onAccuracyChanged(
                    sensor: Sensor?, accuracy: Int) {}
        }

        var gyrXMax = 0.0f
        var gyrYMax = 0.0f
        var gyrZMax = 0.0f

        gyrHorcher = object:SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                if (event == null) return

                val gyrX = (event.values[0].absoluteValue * 10).toInt() / 10.0f
                val gyrY = (event.values[1].absoluteValue * 10).toInt() / 10.0f
                val gyrZ = (event.values[2].absoluteValue * 10).toInt() / 10.0f

                gyrXMax = max(gyrX, gyrXMax)
                gyrYMax = max(gyrY, gyrYMax)
                gyrZMax = max(gyrZ, gyrZMax)

                B.tvGyrX.text = "X: $gyrXMax / $gyrX"
                B.tvGyrY.text = "Y: $gyrYMax / $gyrY"
                B.tvGyrZ.text = "Z: $gyrZMax / $gyrZ"
            }

            override fun onAccuracyChanged(
                    sensor: Sensor?, accuracy: Int) {}
        }

        var magXMax = 0.0f
        var magYMax = 0.0f
        var magZMax = 0.0f

        magHorcher = object:SensorEventListener{
            override fun onSensorChanged(event: SensorEvent?) {
                if (event == null) return

                val magX = (event.values[0].absoluteValue * 10).toInt() / 10.0f
                val magY = (event.values[1].absoluteValue * 10).toInt() / 10.0f
                val magZ = (event.values[2].absoluteValue * 10).toInt() / 10.0f

                magXMax = max(magX, magXMax)
                magYMax = max(magY, magYMax)
                magZMax = max(magZ, magZMax)

                B.tvMagX.text = "X: $magXMax / $magX"
                B.tvMagY.text = "Y: $magYMax / $magY"
                B.tvMagZ.text = "Z: $magZMax / $magZ"
            }

            override fun onAccuracyChanged(
                    sensor: Sensor?, accuracy: Int) {}
        }
    }

    override fun onPause() {
        super.onPause()
        sMan.unregisterListener(accHorcher)
        sMan.unregisterListener(gyrHorcher)
        sMan.unregisterListener(magHorcher)
    }

    override fun onResume() {
        super.onResume()
        sMan.registerListener(accHorcher,
                accSensor, SensorManager.SENSOR_DELAY_NORMAL)
        sMan.registerListener(gyrHorcher,
                gyrSensor, SensorManager.SENSOR_DELAY_NORMAL)
        sMan.registerListener(magHorcher,
                magSensor, SensorManager.SENSOR_DELAY_NORMAL)
    }
}
